var pagar = '';

for(var index1=1; index1<=10; index1++){
  for(var index2=0; index2<=10; index2++){
    pagar = pagar + '#';
  }
  console.log(pagar);
  pagar = '';
}