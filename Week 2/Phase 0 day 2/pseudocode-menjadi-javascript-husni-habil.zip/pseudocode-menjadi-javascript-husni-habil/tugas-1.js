var nama = 'Husni';
var angkaPembilang = 4;
var angkaPenyebut = 5;
var hasilBagi = angkaPembilang/angkaPenyebut;

console.log('Halo ' + nama + ', ' + angkaPembilang + ' dibagi ' + angkaPenyebut + ' adalah sama dengan ' + hasilBagi);