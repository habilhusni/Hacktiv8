var alas = 3;
var tinggi = 5;
var luasSegitiga = (alas*tinggi)/2;

console.log('Luas Segitiga: ' + luasSegitiga);